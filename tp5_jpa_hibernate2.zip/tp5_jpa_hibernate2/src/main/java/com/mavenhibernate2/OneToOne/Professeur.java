package com.mavenhibernate2.OneToOne;

import javax.persistence.*;

@Entity
@Table(name="professeur")

public class Professeur{

	   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long prof_id;
	private String matiere;
	
	//D�finir une relation un-�-un avec l'entit� Personne.
	@OneToOne
	//Sp�cifie que la cl� �trang�re dans la table professeur est nomm�e personne_id
    @JoinColumn(name = "personne_id")
    private Personne personne;

	public Professeur() {
		super();
	}   
	public long getProf_id() {
		return this.prof_id;
	}

	public void setProf_id(long prof_id) {
		this.prof_id = prof_id;
	}   
	public String getMatiere() {
		return this.matiere;
	}

	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	
	public Personne getPersonne() {
		return this.personne;
	}
	
	public void setPersonne(Personne personne) {
		this.personne=personne;
	}
   
}
