package com.mavenhibernate2.OneToMany_ManyToOne;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "adresse")

public class Adresse{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long adresse_id;
	private String rue;
	private String codePostal;
	private String ville;
	
    //la relation entre les entit�s est g�r�e par l'attribut adresse de la classe Departement
    @OneToMany(mappedBy = "adresse",  cascade = CascadeType.ALL)
    private List<Departement> departements= new ArrayList<Departement>(); // Une adresse peut avoir plusieurs d�partements
	
    public Adresse() {
		super();
	}   
	public long getAdresse_id() {
		return this.adresse_id;
	}

	public void setAdresse_id(long adresse_id) {
		this.adresse_id = adresse_id;
	}   
	public String getRue() {
		return this.rue;
	}

	public void setRue(String rue) {
		this.rue = rue;
	}   
	public String getCodePostal() {
		return this.codePostal;
	}

	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}   
	public String getVille() {
		return this.ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}
	
    public List<Departement> getDepartements() {
        return departements;
    }

    public void setDepartements(List<Departement> departements) {
        this.departements = departements;
    }
   
}
