package com.mavenhibernate2.OneToMany_ManyToOne;

import javax.persistence.*;

@Entity
@Table(name="departement")

public class Departement{

	   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long departement_id;
	private String nom;
	
	 @ManyToOne
	 @JoinColumn(name = "adresse_id") // Colonne de cl� �trang�re pour lier un d�partement � une adresse
	 private Adresse adresse;
	 
	public Departement() {
		super();
	}   
	public long getDepartement_id() {
		return this.departement_id;
	}

	public void setDepartement_id(long departement_id) {
		this.departement_id = departement_id;
	}   
	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }
   
}
