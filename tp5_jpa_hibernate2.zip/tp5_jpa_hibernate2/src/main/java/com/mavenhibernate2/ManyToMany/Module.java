package com.mavenhibernate2.ManyToMany;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="module")

public class Module{

	   
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long module_id;
	private String nom;
	
	//indiquer que cette entit� est l'inverseur de la relation Many-to-Many d�finie dans la classe Etudiant
	@ManyToMany(mappedBy = "modules")
    private List<Etudiant> etudiants = new ArrayList<Etudiant>();

	public Module() {
		super();
	}   
	public long getModule_id() {
		return this.module_id;
	}

	public void setModule_id(long module_id) {
		this.module_id = module_id;
	}   
	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
   
	public List<Etudiant> getEtudiants() {
	        return etudiants;
	}

	 public void setEtudiants(List<Etudiant> etudiants) {
	        this.etudiants = etudiants;
	 }
}
